package common;

public enum Type {
    CONSUMABLES, CLERICAL, GADGETS, GAMING, PC
}
